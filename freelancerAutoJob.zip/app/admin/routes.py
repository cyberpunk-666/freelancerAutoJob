from flask import Blueprint, render_template, redirect, url_for, flash
from app.admin.forms import CreateJobForm, UpdateJobForm
from app.models.job_manager import JobManager
from app.db.postgresdb import PostgresDB

admin_bp = Blueprint('admin', __name__)

job_manager = JobManager(PostgresDB)

@admin_bp.route('/admin_dashboard')
def admin_dashboard():
    jobs = job_manager.fetch_all_jobs()
    return render_template('admin_dashboard.html', jobs=jobs)

@admin_bp.route('/create_job', methods=['GET', 'POST'])
def create_job():
    form = CreateJobForm()
    if form.validate_on_submit():
        job_manager.create_job(form.title.data, form.description.data, form.budget.data, form.status.data)
        flash('Job created successfully!', 'success')
        return redirect(url_for('admin.admin_dashboard'))
    return render_template('create_job.html', form=form)

@admin_bp.route('/update_job/<int:job_id>', methods=['GET', 'POST'])
def update_job(job_id):
    job = job_manager.fetch_all_jobs()[0]  # Replace this with a specific job fetch logic
    form = UpdateJobForm(obj=job)
    if form.validate_on_submit():
        job_manager.update_job(job_id, form.title.data, form.description.data, form.budget.data, form.status.data)
        flash('Job updated successfully!', 'success')
        return redirect(url_for('admin.admin_dashboard'))
    return render_template('update_job.html', form=form, job_id=job_id)

@admin_bp.route('/delete_job/<int:job_id>', methods=['POST'])
def delete_job(job_id):
    job_manager.delete_job(job_id)
    flash('Job deleted successfully!', 'success')
    return redirect(url_for('admin.admin_dashboard'))
